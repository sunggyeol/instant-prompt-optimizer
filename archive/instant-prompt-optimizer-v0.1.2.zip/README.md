# Instant Prompt Optimizer

Chrome extension that optimizes your text for AI using Google's Gemini API. Select text, click optimize, done.

## Setup

1. Get a free API key from [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Load the extension in Chrome (`chrome://extensions` → Developer mode → Load unpacked)
3. Click the extension icon and paste your API key

## Usage

1. Select text in any input field on a supported site
2. Click **Optimize** in the popup
3. Click **Replace** or **Copy**

## Supported Sites

Claude, ChatGPT, Gemini, Perplexity, Grok, Google, Bing, DuckDuckGo, GitHub, Stack Overflow, Reddit — plus any custom sites you add.

## Privacy

Text is sent to Google's Gemini API for processing. Only your API key is stored locally.
